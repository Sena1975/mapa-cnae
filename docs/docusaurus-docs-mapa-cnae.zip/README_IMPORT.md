# Como importar estes docs no seu Docusaurus

1. Copie a pasta `docs/` e o arquivo `sidebars.js` para a raiz do seu projeto Docusaurus.
2. Ajuste `docusaurus.config.js` para usar o `sidebarPath`:
   ```js
   // docusaurus.config.js (trecho)
   module.exports = {
     title: 'Mapa CNAE',
     url: 'https://seu-dominio.com',
     baseUrl: '/',
     presets: [
       [
         'classic',
         ({ docs: { sidebarPath: require.resolve('./sidebars.js') } })
       ],
     ],
   };
   ```
3. Rode:
   ```bash
   npm install
   npm run start
   # ou
   npm run build
   ```
