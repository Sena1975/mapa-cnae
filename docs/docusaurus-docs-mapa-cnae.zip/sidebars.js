/** @type {import('@docusaurus/plugin-content-docs').SidebarsConfig} */
const sidebars = {
  docs: [
    'intro',
    'instalacao',
    'configuracao',
    'base-de-dados',
    {
      type: 'category',
      label: 'CLI',
      collapsed: false,
      items: ['cli/mapa-warm'],
    },
    {
      type: 'category',
      label: 'Guias',
      collapsed: false,
      items: ['guias/desempenho', 'guias/dbeaver'],
    },
    'faq',
  ],
};

module.exports = sidebars;
